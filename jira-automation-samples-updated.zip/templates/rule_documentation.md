# JIRA Automation Rule Documentation Template

**Rule Name:** Auto Assign Bug Tickets
**Trigger:** Issue Created
**Condition:** Issue Category = Bug
**Action:** Assign to Backend Support Group
